Universidade de Brasilia
Instituto de Ciencias Exatas
Departamento de Ciencia da Computacao

Algoritmos e Programação de Computadores – 1/2018

Aluno(a): Luis Filipe Siqueira Ribeiro
Matricula: 180053906
Turma: A
Versão do compilador: gcc (Ubuntu 5.4.0-6ubuntu1~16.04.9) 5.4.0 20160609

Descricao: Jogo no qual o jogador (representado por um '+') deve desviar dos inimigos (representados por um 'X')


-_______

Compilado usando:   gcc -ansi -Wall -o
Adicionada biblioteca string.h
Nenhum extra


